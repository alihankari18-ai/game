import { test } from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { createEngine, profiles } from '../server/engine.mjs';

function player(condition='actionable'){
  const e=createEngine(':memory:',{assign:()=>condition});const {token,state:first}=e.create({adult:true,consent:true,device_class:'desktop'});let s=first;
  const command=(type,extra={})=>{s=e.command(token,{request_id:randomUUID(),revision:s.revision,type,...extra});return s;};
  const view=()=>command('view');
  const act=action=>{view();return command('action',{action,decision_id:s.decision.id,active_ms:0});};
  return {e,token,view,act,command,get s(){return s;},events:()=>e.export(token).events};
}
test('consent gate, no session before explicit consent',()=>{
  const e=createEngine();assert.throws(()=>e.create({adult:true,consent:false}));assert.equal(e.db.prepare('SELECT COUNT(*) AS n FROM sessions').get().n,0);e.close();
});
test('lost consent response can be retried without creating a second participant',()=>{
  const e=createEngine();const body={adult:true,consent:true,creation_token:'b'.repeat(64)};
  const first=e.create(body);const second=e.create(body);assert.deepEqual(first,second);
  assert.equal(e.db.prepare('SELECT COUNT(*) AS n FROM sessions').get().n,1);
  assert.equal(e.export(first.token).events.filter(x=>x.event_type==='consent_granted').length,1);e.close();
});
for(const condition of ['actionable','generic'])for(const profile of Object.keys(profiles))test(`${condition}/${profile}: costs, persistence, draft and one completion`,()=>{
  const p=player(condition);p.act('choose_'+profile);assert.equal(p.s.condition,condition);p.act('bus_begin');assert.equal(p.s.time,profiles[profile].time);
  p.act('bus_pre_pass');assert.equal(p.events().filter(x=>x.event_type==='feedback_shown').length,0);p.view();assert.equal(p.events().filter(x=>x.event_type==='feedback_shown').length,1);p.act('bus_reply_continue');
  p.act('bus_proposal_open');p.act('bus_priority_access');p.act('bus_solution_trial');p.act('bus_proposal_save');assert.equal(p.s.time,profiles[profile].time);assert.equal(p.s.primary,null);
  assert.equal(p.e.state(p.token).priority,'access');p.act('bus_materials');const afterInfo=profiles[profile].time-profiles[profile].info;assert.equal(p.s.time,afterInfo);p.act('bus_materials_back');p.act('bus_materials');assert.equal(p.s.time,afterInfo);p.act('bus_materials_back');
  p.act('bus_proposal_open');p.view();const body={request_id:randomUUID(),revision:p.s.revision,type:'action',action:'bus_proposal_submit',decision_id:p.s.decision.id,active_ms:0};
  const saved=p.e.command(p.token,body);const duplicate=p.e.command(p.token,body);assert.deepEqual(saved,duplicate);assert.equal(saved.time,afterInfo-profiles[profile].submit);assert.equal(saved.primary,1);
  assert.equal(p.events().filter(x=>x.event_type==='formal_action_completed').length,1);assert.equal(p.events().filter(x=>x.event_type==='formal_action_started').length,1);assert.equal(p.events().filter(x=>x.event_type==='condition_assigned').length,1);
  const second={...body,request_id:randomUUID(),revision:saved.revision};assert.throws(()=>p.e.command(p.token,second));assert.equal(p.events().filter(x=>x.event_type==='formal_action_completed').length,1);
  const events=p.events();assert.deepEqual(events.map(x=>x.seq),events.map((_,i)=>i+1));assert.ok(events.every(x=>x.study_phase==='dev'));assert.equal(p.e.export(p.token).session.full_game_complete,false);p.e.close();
});
test('unobserved primary stays null; voluntary end is zero; reflection can be skipped',()=>{
  const p=player();p.act('choose_digital');p.act('bus_begin');p.act('bus_pre_info');p.act('bus_reply_continue');assert.equal(p.e.export(p.token).session.bus_primary,null);
  p.act('bus_end_confirm');assert.equal(p.s.primary,0);p.act('clarity_skip');assert.equal(p.s.clarity,null);assert.equal(p.s.prototype_complete,true);assert.equal(p.events().filter(x=>x.event_type==='session_ended').length,0);p.e.close();
});
test('invalid sequence and forged choices rollback; stale tab cannot mutate',()=>{
  const p=player();const before=p.events().length;assert.throws(()=>p.command('action',{action:'bus_proposal_submit',decision_id:randomUUID(),active_ms:0}));assert.equal(p.events().length,before);
  p.act('choose_digital');const revision=p.s.revision;p.view();assert.throws(()=>p.e.command(p.token,{request_id:randomUUID(),revision,type:'view'}));p.act('bus_begin');p.act('bus_pre_support');p.act('bus_reply_continue');p.act('bus_proposal_open');assert.throws(()=>p.act('bus_proposal_submit'));assert.throws(()=>p.act('bus_priority_secret'));p.e.close();
});
test('tokens isolate exports and deletion cascades events and request receipts',()=>{
  const p=player();const other=p.e.create({adult:true,consent:true});p.act('choose_community');assert.throws(()=>p.e.export('a'.repeat(64)));assert.notEqual(p.e.export(p.token).session.session_id,p.e.export(other.token).session.session_id);
  const id=p.s.id;p.e.remove(p.token);assert.throws(()=>p.e.state(p.token));assert.equal(p.e.db.prepare('SELECT COUNT(*) AS n FROM events WHERE session_id=?').get(id).n,0);assert.equal(p.e.db.prepare('SELECT COUNT(*) AS n FROM receipts WHERE session_id=?').get(id).n,0);assert.equal(p.e.state(other.token).phase,'characters');p.e.close();
});
